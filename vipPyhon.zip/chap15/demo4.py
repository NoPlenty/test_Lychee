file = open('b.txt', 'w')   #w 以只读模式打开文件，如果文件不存在则创建，如果文件存在则覆盖原有内容
file.write('Python')
file.close()