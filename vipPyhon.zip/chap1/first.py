print(520)
print(98.5)


#可以输出字符串
print("hello world")


#含有运算符的表达式
print(1+2)


#将数据输出到文件中，注意点：1.指定的盘要存在。2.使用file=的形式
fp = open("D:/text.txt",'a+')   #a+的意思是：如果文件不存在就创建，如果存在就在该文件后面继续追加
print("helloworld",file = fp)
fp.close()


#不进行换行输出
print("hello","world","python")