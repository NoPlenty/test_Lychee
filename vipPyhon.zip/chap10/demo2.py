def fun(arg1, arg2):
    print('arg1:', arg1)
    print('arg2:', arg2)
    arg1 = 100
    arg2.append(300)
    print('arg1', arg1)
    print('arg2', arg2)


n1 = 1
n2 = [9, 8, 7]
print('n1',n1)
print('n2',n2)
fun(n1, n2)  #将位置传参，arg1,arg2是函数定义处的形参，n1,n2为函数调用处的实参。总结：实参名称和形参名称可以不一致
print('n1',n1)
print('n2',n2)

'''
在函数调用的过程中，进行参数的传递
如果是不可变对象，在函数体的修改不会影响实参的值 arg1的修改为100，不会影响n1的值
如果是可变对象，在函数体的修改会影响实参的值 arg2的修改.append(100) 会影响到n2的值
'''