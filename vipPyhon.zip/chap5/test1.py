for i in range(1, 51):
    if i % 5 != 0:
        continue
    else:
        print(i)

for i in range(3):
    pwd = int(input('请输入您的密码：'))
    if pwd == 999:
        print('密码正确！')
        break
    else:
        print('密码错误！')
else:
    print('三次密码均输入错误！您的账号已经被锁')

a = 3
while a > 0:
    pwd = int(input('请输入您的密码：'))
    if pwd == 999:
        print('密码正确！')
        break
    else:
        print('密码错误！')
        a = a - 1
else:
    print('三次密码均输入错误，您的卡已经被冻结！')

sum = 0
for i in range(101):
    if i % 2 == 0:
        sum = sum + i
print('1到100之间的偶数和为：', sum)

for i in range(100, 1000):
    ge = i % 10
    shi = i // 10 % 10
    bai = i // 100
    if i == ge ** 3 + shi ** 3 + bai ** 3:
        print('水仙花数有:',i)
