scores = {'张三': 98, '李四': 100, '王五': 45}
'''字典元素的遍历'''
for item in scores:
    print(item,scores[item],scores.get(item))