'''字典的创建方式'''
'''使用{}创建字典'''
scores = {'张三': 98, '李四': 100, '王五': 45}
print(scores)
print(type(scores))

'''第二种方式创建字典'''
student = dict(name='Jack', age=2)
print(student)

'''创建空字典'''
d = {}
print(d)
