a = 11
b = 22
print(a + b)
