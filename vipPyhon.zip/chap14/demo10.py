import sys
import time
import urllib.request
import math

print(sys.getsizeof(24))
print(sys.getsizeof(28))
print(sys.getsizeof(True))
print(sys.getsizeof(False))
print(time.time())
print(time.localtime(time.time()))
print(urllib.request.urlopen('http://www.baidu.com').read())
print(math.pi)