d={'name':'张三','name':'李四'}
print(d)            #key不允许重复

d={'name':'张三','nikename':'张三'}
print(d)            #value允许重复