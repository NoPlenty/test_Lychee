'''集合的创建方式'''

#第一种创建方式：使用{}
s={1,2,3,3,3,4,5,6,6,7,8}
print(s)   #集合中的元素不允许重复

'''第二种创建方式：使用内置函数set'''
s1=set(range(6))
print(s1,type(s1))

s2=set([1,2,2,3,4,5,5,6])
print(s2,type(s2))

s3=set((1,2,3,4,5,5,5,65))  #集合的元素是无序的
print(s3,type(s3))

s4=set('python')
print(s4,type(s4))  #集合的元素是无序的

s5=set({1,2,3,4,5,5,5,6,7})
print(s5,type(s5))

#定义一个空集合
s6={}   #dict,字典类型
print(s6,type(s6))

s7=set()
print(s7,type(s7))
