# 字符串的查询操作

s = 'hello,hello'
print(s.index('lo'))
print(s.find('lo'))
print(s.rindex('lo'))
print(s.rfind('lo'))

#print(s.index('k'))   #ValueError: substring not found
print(s.find('k'))
#print(s.rindex('k'))    ValueError: substring not found
print(s.rfind('k'))

'''index查找字符串第一次出现的位置，如果字符串不存在就会抛出ValueError'''
'''find查找字符串第一次出现的位置，如果字符串不存在就会返回数值-1'''
'''rindex查找字符串最后一次出现的位置，如果字符串不存在就会抛出ValueError'''
'''rfind查找字符串最后一次出现的位置，如果字符串不存在就会返回数值-1'''