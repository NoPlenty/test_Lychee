age = input('请输入您的年龄：')
print(type(age))
if int(age) >= 18:
    print('您已经成年')

i = 0
while i < 10:
    print(i)
    i += 1
