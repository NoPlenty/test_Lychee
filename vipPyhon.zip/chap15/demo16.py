import os

print(os.getcwd())  # 获取当前的工作目录

lst = os.listdir('../chap15')  # 返回指定路径下的文件和目录信息
print(lst)

# os.mkdir('newdir2') #创建新的目录
# os.makedirs('A/B/C') #创建多级目录
# os.rmdir('newdir2') #删除目录
#os.removedirs('A/B/C')  # 删除多级目录
#os.chdir(r'D:\PycharmProjects\vipPyhon\chap1') 将path设置为当前工作目录
#print(os.getcwd())