str1  = '人生苦短，我用python'
str2  = "人生苦短，我用python"
str3 = '''人生苦短，     
我用python'''
str4 = """人生苦短，
我用python"""

print(str1,type(str1))
print(str2,type(str2))
print(str3,type(str3))  #使用三引号可以换行输出
print(str4,type(str4))