from math import pi
from math  import pow
import math

print(pi)
print(pow(2, 3))
#print(math.pow(2, 3))
