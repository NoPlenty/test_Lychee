def fun():
    pass
def fun2():
    pass
class Student():
    native_place='安徽'   #类属性
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def eat(self):
        pass
    @classmethod
    def cm(cls):
        pass
    @staticmethod
    def sm():
        pass

a=1
b=2
print(a+b)
'''模块可以包含函数、类、语句'''
'''类中包含类属性、静态方法、类方法、实例属性'''
'''一个项目里可以有n多个模块'''