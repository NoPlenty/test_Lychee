scores = {'张三': 98, '李四': 100, '王五': 45}
'''获取所有的keys'''
keys=scores.keys()
print(keys,type(keys))      #将所有的key组成的视图转换成列表
print(list(keys))

'''获取所有的value'''
values=scores.values()
print(values)
print(type(values))
print(list(values))

'''获取所有的key-value对'''
items=scores.items()
print(items)
print(type(items))
print(list(items))#元组：转换之后的列表元素由元组组成