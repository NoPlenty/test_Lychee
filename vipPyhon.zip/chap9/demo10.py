'''111'''

'''字符串的切片'''
s = 'hello,Python'
s1 = s[:5]
s2 = s[6:]
newstr = s1 + '!' + s2
print(s1)
print(s2)
print(newstr)

print('----------------')
print(id(s1))
print(id(s2))
print(id(newstr))

print('-----------------切片[start:end:step]-----------------')
print(s[1:5:1])   #从1开始截到5（不包含5），步长为1
print(s[::2])     #没写开始就默认从0开始，没写结束就默认到结束，步长为2
print(s[::-1])    #默认从最后一个位置开始，步长为-1
print(s[-6::1])   #从索引为-6开始，到字符串的最后一位，步长为1