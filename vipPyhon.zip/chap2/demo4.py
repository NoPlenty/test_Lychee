f1 = True
f2 = False
print(f1, type(f1))
print(f2, type(f2))

# 布尔值可以转成整数计算
print(f1 + 1)  # 2,1+1的结果为2，True的值是1
print(f2 + 1)  # 1，0+1的结果是1，False的值是0
