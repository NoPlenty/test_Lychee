'''多分支结构，多选一执行
从键盘录入一个成绩，评定等级
100-90A,90-80B,80-70C,70-60D,60-E
'''

score=int(input('请输入一个整数：'))
if score>=90 and score<=100:
    print('A级')
elif score>=80 and score<90:
    print('B级')
elif score>=70 and score<80:
    print('C级')
elif score>=60 and score<70:
    print('D级')
elif score>=0 and score<60:
    print('E级')
else:
    print('对不起，成绩有误')