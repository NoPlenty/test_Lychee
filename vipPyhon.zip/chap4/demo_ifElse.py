# 双分支结构，二选一结构
# 编写一个程序，让计算机判断是奇数还是偶数

num = int(input('请输入一个整数：'))
# 条件判断语句
if num % 2 == 0:
    print(num, '是偶数')
else:
    print(num, '是奇数')
