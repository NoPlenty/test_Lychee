file = open('c.txt', 'a')
#file.write('hello')
lst=['java','girl','python']
file.writelines(lst)    #追加到a.txt文件中
file.close()
