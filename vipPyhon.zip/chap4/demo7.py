age = int(input('请输入您的年龄：'))
if age:
    print(age)
else:
    print('年龄为：', age)
