
def fun(a,b=10):  #b是在函数的定义处，所以是形参，而且赋值了，所以b称为默认值形参
    print('a=',a)
    print('b=',b)

def fun2(*args):    #个数可变的位置形参
    print(args)

def fun3(**args):   #个数可变的关键字形参
    print(args)


fun(1,2)
fun2(11,22,3,44,55,66)
fun3(a=11,b=22,c=33,d=55)


def fun4(a,b,*,c,d):    #从*之后的参数，在调用时只能采用关键字形参
    print('a=',a)
    print('b=',b)
    print('c=',c)
    print('d=',d)


#调用fun4()函数
#fun4(9,8,7,6)    #位置实参传递
fun4(a=1,b=2,c=3,d=5)   #关键字实参传递
fun4(1,2,c=3,d=4)   #前两个参数采用的是位置实参，后两个参数采用的是关键字实参
'''需求：c,d只能采用关键字实参传递'''

'''函数定义时的形参的顺序问题'''
def fun5(a,b,*,c,d,**args):
    pass

def fun6(*args,**args2):
    pass

def fun7(a,b=10,*args,**args2):
    pass
