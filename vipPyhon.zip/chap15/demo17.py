import os.path

print(os.path.abspath('demo13.py'))  # 获取文件或者目录的绝对路径
print(os.path.exists('demo13.py'), os.path.exists('demo19.py'))
# 用于判断文件或目录是否存在，存在返回True,不存在返回False
print(os.path.join('E:\\Python', 'demo13.py'))  # 对路径进行拼接
print(os.path.split('E:\\Python\\chap15\\demo13.py'))  # 分离文件名和拓展名
print(os.path.splitext('demo13.py'))  # 分离文件名和后缀名
print(os.path.basename('E:\\Python\\chap15\\chap13.py'))  # 提取文件名
print(os.path.dirname('E:\\Python\\chap15\\chap13.py'))  # 提取目录名
print(os.path.isdir('E:\\Python\\chap15\\chap13.py'))  # 判断是否为目录


