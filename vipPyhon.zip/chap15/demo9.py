file = open('c.txt', 'r')
file.seek(2)  # 一个汉字两个字节，从第二个汉字开始
print(file.read())
print(file.tell())
file.close()
