a = 10
b = 200
c = a + b  # 两个整数类型的对象的相加操作
d = a.__add__(b)

print(c)
print(d)


class Student():
    def __init__(self, name):
        self.name = name

    def __add__(self, other):
        return self.name + other.name

    def __len__(self):
        return len(self.name)


stu1 = Student('Lyric')
stu2 = Student('李四')
s = stu1 + stu2  # 实现两个对象的加法运算（因为在Student类当中编写了__add__()特殊的方法）
print(s)
s = stu1.__add__(stu2)
print(s)
print('-----------------------------------------')
lst = [11, 22, 33, 44]
print(len(lst))  # len是内容函数len，可以计算列表的长度
print(lst.__len__())  #和上面等价
print(len(stu1))    #在Student类当中编写了__len__()特殊的方法
