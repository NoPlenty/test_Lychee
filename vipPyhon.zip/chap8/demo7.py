

'''两个集合是否相等：元素相同就相等'''
s1 = {1, 2, 3, 4}
s2 = {4, 3, 2, 1}
print(s1 == s2)   #集合元素没有顺序，只要元素相同那么两个集合就相同
print(s1 != s2)

'''一个集合是否是另一个集合的子集'''
s1={1,2,3,4,5,6}
s2={1,2,3,4}
s3={5,6,7}

print(s2.issubset(s1))  #True
print(s3.issubset(s1))  #False

'''一个集合是否是另一个集合的超集'''
print(s1.issuperset(s2))    #True
print(s1.issuperset(s3))    #False

'''两个集合是否有交集'''
print(s1.isdisjoint(s2))    #False 有交集为False
s4={9,8}
print(s1.isdisjoint(s4))    #True 没有交集为True