lst = [11, 22, 33, 44]  # 列表的索引是从0开始的
#print(lst[4])  # list index out of range
print(lst[3])

lst2=[]
#lst2=append('C')
lst2.append('A')
lst2.append('B')
lst2.append('C')
print(lst2)