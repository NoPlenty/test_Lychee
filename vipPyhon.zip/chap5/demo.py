''''
输出一个三行四列的矩形
'''
for i in range(0,3):
    for j in range(0,4):
        print('*',end='\t') #不换行输出
    print()   #换行