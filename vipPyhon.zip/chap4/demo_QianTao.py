'''
会员：   >=200  8折
        >=100  9折
        不打折
非会员   >=200  9.5折
        否则    不打折
'''

#外层判断是否是会员
answer=input('您是会员吗?y/n')
money=int(input('请输入您的购物金额：'))
if answer=='y':
    print('会员')
    if money>=200:
        print('打八折，付款金额为：',money*0.8)
    elif money>=100:
        print('打九折，付款金额为：',money*0.9)
    else:
        print('不打折，付款金额为：',money)
else:
    print('非会员')
    if money>=200:
        print('打九点五折，付款金额为：',money*0.95)
    else:
        print('不打折，付款金额为：',money)