print("1hello\nworld")
print('2hello\tworld')
print('3helloooo\tworld')    #\t表示一个tab 每四个构成一个tab
print('4hello\rworld')   #\r表示将输出转移到本行开头
print('5hello\bworld')  #\b是退格的意思

print("http:\\\\www.baidu.com")
print('老师说:\'大家好\'')  #如果想在输出语句里面包含单引号，可以用\来引用，当然也可以直接用中文的引号

#原字符，不希望字符串中的转义字符起作用，就使用原字符，就是在字符串之前加上r，或者R
print(r'hello\nworld')
#注意事项：最后一个字符不能是反斜杠\
#print(r'hello\nworld\')