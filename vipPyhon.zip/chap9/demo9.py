'''111'''
'''字符串的比较'''

a='apple'
b='app'
print(a>b)  #True

c='banana'
print(a>c)   #False,97>98?
print(ord('a'))    #两个字符比较时，比较的是原始值ord
print(ord('b'))
print(ord('李'))

print(chr(97))
print(chr(98))
print(chr(26446))

'''==与 is 的区别'''
'''==表示的是value相等，而is表示的是id相等'''
q='123'
w='123'
print(q==w)
print(q is w)
print(id(q))
print(id(w))       #value和id都相等