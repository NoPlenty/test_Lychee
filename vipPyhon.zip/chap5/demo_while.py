a = 1
#判断语句表达式
while a < 10:
    #执行条件执行体
    print(a)
    a += 1
