class Person(object):
    def __init__(self, name, age):
        self.name = name
        self.age = age
    def info(self):
        print(self.name, self.age)


class Student(Person):
    def __init__(self, name, age, stu_num):
        super().__init__(name, age)
        self.stu_num = stu_num
    def info(self):
        super().info()  #调用父类中的方法
        print('学号是',self.stu_num)



class Teacher(Person):
    def __init__(self, name, age, teachofyear):
        super().__init__(name, age)
        self.teachofyear = teachofyear
    def info(self):
        super().info()
        print('教龄是',self.teachofyear,'年')


stu = Student('张三', 19, 20201103)
teacher = Teacher('李四', 34, 10)
stu.info()
print('------------------------------------------')
teacher.info()
