lst = [i * i for i in range(1, 10)]
print(lst)

'''列表中的元素的值为2,4,6,8,10'''
lst2 = [2 * i for i in range(1, 6)]
print(lst2)
