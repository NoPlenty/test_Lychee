# 列表生成式
s1 = [i * i for i in range(9)]
print(s1)

# 集合生成式
s2 = {i * i for i in range(9)}
print(s2)
