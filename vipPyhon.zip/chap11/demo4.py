a = int(input('请输入第一个整数：'))
b = int(input('请输入第二个整数：'))
result = a / b
print(result)
