"""不可变序列 可变序列"""
"""可变序列：字典、列表"""
lst1=[10,20,30]
print(id(lst1))
lst1.append(45)
print(id(lst1))

"""不可变序列：元祖 字符串"""
s='hello'
print(id(s))
s=s+'world'
print(s)
print(id(s))