#数学运算异常
#print(10/0)    #ZeroDivisionError: division by zero

lst=[11,22,33,44]
#print(lst[4])   #IndexError 索引是从0开始的

dict={'name':'张三','age':19}
#print(dict['gender'])   #KeyError: 'gender'

#print(num)  #NameError: name 'num' is not defined

#int a=20   #SyntaxError: invalid syntax  语法错误，变量是没有数据类型的

#a=int('hello')    #ValueError: invalid literal for int() with base 10: 'hello'  字符串不能转化为整型

b=int(10.4)
print(b)