file = open('a.txt', 'r')
print(file.readlines())
file.close()