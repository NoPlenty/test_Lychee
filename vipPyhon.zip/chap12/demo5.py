class Student():  # Student就是类的名称（类名），每个单词的首字母大小，其余小写
    native_pace = '安徽'  # 直接写在类里面的变量，称为类属性

    def __init__(self, name, age):
        self.name = name  # self.name称为实例属性，进行了一个赋值的操作，将局部变量的name的值赋给了实例属性
        self.age = age

    # 实例方法
    def eat(self):
        print('学生在吃饭')

    # 静态方法
    @staticmethod
    def method():  # 不允许写self
        print('我使用了staticmethod进行修饰，所以我是静态方法')

    # 类方法
    @classmethod
    def cm(cls):
        print('我是类方法，因为我使用了classmethod进行修饰')


# 在类之外定义的叫函数，在类里面定义的叫方法
def drink():
    print('学生在喝水')


print('------------------类属性的使用方式----------------------')
print(Student.native_pace)
stu1=Student('张三',19)
stu2=Student('李四',22)
Student.native_pace='天津'
print(stu1.native_pace)
print(stu2.native_pace)
print('-------------------类方法的使用方式-----------------------')
Student.cm()
print('------------------静态方法的使用方式----------------------')
Student.method()
print('--------------------实例方法的两种使用方式-----------------------')
stu1.eat()
Student.eat(stu1)
'''类属性、类方法、静态方法都是类名.来使用，而实例方法使用对象名.'''