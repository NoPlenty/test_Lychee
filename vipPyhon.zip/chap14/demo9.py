#在导入带有包的模块时的注意事项
import Package1
import calc
#使用Import方式导入时，只能跟包名或者模块名

from Package1 import module_A
from Package1.module_A import  a
#使用from...import可以导入模块，函数，变量