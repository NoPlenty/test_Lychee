
s='天涯共此时'
#编码
print(s.encode(encoding='GBK'))   #在GBK这种格式中，一个中文字符占2个字节
print(s.encode(encoding='UTF-8'))   #在UTF-8这种格式中，一个中文占3个字节

#解码
#byte代表一个二进制数据（字节类型的数据）
byte=s.encode(encoding='GBK')
print(byte.decode(encoding='GBK'))

byte=s.encode(encoding='UTF-8')
print(byte.decode(encoding='UTF-8'))