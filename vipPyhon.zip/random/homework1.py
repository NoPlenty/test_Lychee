def favorite_book(name):
    print('One of my favorite book is '+name)

favorite_book('Alice in Wonderland')