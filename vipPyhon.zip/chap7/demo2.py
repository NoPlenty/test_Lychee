'''获取字典中的元素'''
scores = {'张三': 98, '李四': 100, '王五': 45}
'''第一种方式'''
print(scores['张三'])
#print(scores['陈六'])   #KeyError: '陈六'

'''第二种方式'''
print(scores.get('张三'))
print(scores.get('陈六')) #None
print(scores.get('麻七',99))  #99是'麻七'对应的value不存在时的默认值