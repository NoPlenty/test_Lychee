import math  # 关于数学运算的模块

print(id(math))
print(type(math))
print(math)
print(math.pi)
print('----------------------------------')
print(dir(math))
print(math.pow(2, 3))  # 2的3次方
print(math.ceil(9.001)) #向上取整
print(math.floor(9.999))    #向下取整

