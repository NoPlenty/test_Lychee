# 从键盘录入两个整数，计算两个整数的和

# a = input('请输入一个加数：')
# a = int(a)    #将装换之后的结果存储给a
a = input('请输入一个加数：')
b = input('请输入另一个加数：')
print(type(a), type(b))
print(int(a) + int(b))
