lst=[{'rating':[9,7,50],'id':111,'type':['犯罪','剧情'],'title':'肖申克的救赎','actors':['罗宾斯','弗里曼']},
     {'rating':[9,6,50],'id':222,'type':['剧情’，‘爱情','同性'],'title':'霸王别姬','actors':['张国荣','葛优']},
     {'rating':[9,8,60],'id':333,'type':['剧情','犯罪','悬疑'],'title':'控方证人','actors':['保华','戴德利']}]


name=input('请输入您要查找的演员：')
for items in lst:
    #print(items)
    new_actor=items['actors']
    #print(new_actor)
    if name in new_actor:
        print(name,'出演了',items['title'])


'''第一个for循环遍历可以得到每一部电影，而每一部电影又是一个字典，只需要根据key在字典中取值即可。根据演员的
键actors取出演员的列表，使用判断name在列表中是否存在，最后根据电影名称键title取出电影的名称，进行输出'''
