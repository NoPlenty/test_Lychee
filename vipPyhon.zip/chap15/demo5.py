file = open('b.txt', 'a')  # w改成a就会在原有的内容上追加
file.write('Python')
file.close()
