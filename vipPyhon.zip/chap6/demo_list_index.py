lst=['hello','world',98,'hello']
print(lst.index('hello'))       #如果有相同元素。只查找第一个元素
#print(lst.index('python'))    #ValueError: 'python' is not in list
print(lst.index('hello',1,4))  #从第1个元素到第3个元素里有'hello'
print(lst.index('world'))