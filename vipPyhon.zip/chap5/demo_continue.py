'''
    要求输出1到50之间所有5的倍数    5 10 15...
    5的倍数的特点：和5的余数为0的数都是5的倍数
    什么样的数不是5的倍数：1,2,3,4,6,7,8... 与5的余数不为0的数都不是5的倍数
    要求是用continue实现
'''

for item in range(1, 51):
    if item % 5 == 0:
        print(item)

print('--------------使用continue实现-----------------')
for item in range(1, 51):
    if item % 5 != 0:
        continue
    else:
        print(item)
