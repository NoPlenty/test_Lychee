# 字符串的劈分、
s = 'hello world python'
lst = s.split()
print(lst)
s1 = 'hello|world|python'
print(s1.split(sep='|'))   #遇到|就分割
print(s1.split(sep='|',maxsplit=1))

'''rsplit() 从右侧开始劈分'''
print(s.rsplit())
print(s1.rsplit(sep='|'))
print(s1.rsplit(sep='|',maxsplit=1))