print(bool(0))
print(bool(9))   #False，非零值的布尔值是False
