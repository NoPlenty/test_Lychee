'''key的判断'''

scores = {'张三': 98, '李四': 100, '王五': 45}
print('张三' in scores)
print('张三'not in scores)

'''key的删除'''
del scores['张三']
print(scores)

'''清空字典'''
#scores.clear()  #清空字典的元素
print(scores)
scores['陈六']=98
print(scores)