class Student():  # Student就是类的名称（类名），每个单词的首字母大小，其余小写
    pass


# Python中一切皆对象，Student是对象吗？它有开空间吗？
print(id(Student))  # 2865671343280
print(type(Student))  # <class 'type'>
print(Student)  # <class '__main__.Student'>
