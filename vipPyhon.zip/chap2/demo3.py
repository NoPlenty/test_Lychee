a = 3.14159
print(a, type(a))
n1 = 1.1
n2 = 3.2
n3 = 2.1
print(n1 + n2)    #使用浮点数进行就计算时，可能会出现小数位数不确定的情况
print(n1 + n3)

from decimal import Decimal

print(Decimal('1.1') + Decimal('2.2'))
