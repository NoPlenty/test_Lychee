#函数的定义
def fun(a,b=100):
    print(a,b)


#函数的调用
fun(10)   #参数不够就使用函数定义里的默认值
fun(1,2)    #参数够了就使用实参

print('hello',end='\t')
print('world')