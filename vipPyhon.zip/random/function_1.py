def pet(pet_type,name):
    print('I have a '+pet_type+'.')
    print('My '+pet_type+"'s name is  "+name+'.')
pet('hamster','Harry')