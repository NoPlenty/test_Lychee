'''函数的定义'''
def greet_user(username):
    print('hello,'+username+'!')

greet_user('Lychee')
