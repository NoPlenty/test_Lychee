'''集合的相关操作'''

'''集合元素的判断操作'''
s={1,2,3,4,5}
print(1 in s)   #True
print(12 in s)  #False


'''集合元素的添加操作'''
s.add(800)      #一次只添加一个元素
print(s)

s.update({100,200,300})     #一次至少添加1个元素
print(s)

s.update([133,555,666])     #可添加列表
s.update((111,222233))      #可添加元组
print(s)


'''集合元素的删除操作'''
# s.remove(500)  KeyError: 500,因为500不在里面
print(s)
s.discard(500)
print(s)   #不会报错
s.pop()     #pop不能添加参数
print(s)    #pop删除任意一个元素，我们并不知道是哪个元素

s.clear()   #清空集合元素
print(s)