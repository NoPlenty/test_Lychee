print('你好，中国！')
#python的默认格式为UTF-8