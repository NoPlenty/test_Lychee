# 输入函数
present = input('大圣想要什么礼物呢？')
print(present,type(present))
