#在demo8的模块中导入package1包
import Package1.module_A as ma  #ma是Package1.module_A的别名
#print(Package1.module_A.a)
print(ma.a)