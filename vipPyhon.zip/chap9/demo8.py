

#字符串的替换
s='hello,Pyhon'
print(s.replace('Pyhon','Java'))
s1='hello,Python,Python,Python'
print(s1.replace('Python','Java',2))

lst=['hello','python','java']
print('|'.join(lst))
print(''.join(lst))

t=('hello','java','python')
print(''.join(t))

print('*'.join('Python'))