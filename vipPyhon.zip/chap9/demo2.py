s1 = 'abc%'
s2 = 'abc%'
print(s1 is s2)
