print(type(open('a.txt', 'r')))
with open('a.txt', 'r') as file:
    print(file.read())  # 这时不用再写close()语句，因为with语句会自动释放资源

#open('a.txt','r')称为上下文管理器
