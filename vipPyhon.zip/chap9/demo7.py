'''字符串判断的相关方法'''

s='hello,python'
print('1.',s.isidentifier())   #是否为有效字符串：字母数字和下划线
print('2.','hello'.isidentifier())
print('3.','张三123_'.isidentifier())
print('4.','zyh_12'.isidentifier())

print('5.','\t'.isspace())    #是否是空白字符

print('6.','asd'.isalpha())     #s是否由字母构成
print('7.','张三1'.isalpha())

print('8.','张三'.isdecimal())   #是否由十进制组成
print('9.','123'.isdecimal())

print('10.','1234'.isnumeric())     #是否由数字构成
print('11.','123de'.isnumeric())
print('12.','123四'.isnumeric())   #注意，四 也是数字

print('13.','123er'.isalnum())    #是否全部由字母和数字组成
print('14.','asd!'.isalnum())
