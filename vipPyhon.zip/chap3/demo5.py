# 比较运算符
a, b = 10, 20
print('a>b吗？', a > b)  # False
print('a<b吗？', a < b)  # True
print('a<=b吗？', a <= b)  # True
print('a>=b吗？', a >= b)  # False
print('a=b吗？', a == b)  # False
print('a!=b吗？', a != b)  # True

'''
一个 = 称为赋值运算符，两个 == 称为比较运算符
一个变量由三部分组成，标识 类型 值
== 比较的是指还是标识呢？  比较的是值
比较对象的标识使用的是 is
'''

a = 10
b = 10
print(a == b)  # True,说明a与b的值相等
print(a is b)  # True，说明a与b的id相同

list1 = [11, 22, 33, 44]
list2 = [11, 22, 33, 44]
print(list1 == list2)   #True
print(list1 is list2)   #False
print(id(list1))
print(id(list2))
print(a is not b)   #False，a的id与b的id是相等的
print(list1 is not list2)   #True,list1的id和list2的不相等