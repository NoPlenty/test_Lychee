def fun(num):
    odd = []  # 存奇数
    even = []  # 存偶数
    for i in num:
        if i % 2:
            odd.append(i)
        else:
            even.append(i)
    return odd, even


# 函数的调用
lst = [12, 44, 56, 77, 89, 71]
print(fun(lst))

'''
  函数的返回值
（1）如果函数没有返回值，即函数执行完毕后不需要给调用处提供数据，这时return可以不写
（2）函数的返回值如果是一个，直接返回原类型
（3）函数的返回值如果是多个，返回的是元组
'''


def fun1():
    print('hello')
    # return


fun1()


def fun2():
    return 'hello'

res=fun2()
print(res)


def fun3():
    return 'hello', 'world'


print(fun3())


'''函数在定义时，是否需要返回值需要视情况而定'''
