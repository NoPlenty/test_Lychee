#os模块，和操作系统相关的一个模块（可以调用系统的文件）
import os
#os.system('notepad.exe')
#os.system('calc.exe')
#直接调用可执行文件
os.startfile(r"D:\Program Files\Tim\Bin\QQScLauncher.exe")