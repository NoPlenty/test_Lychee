'''创建列表的第一种方法，使用[]'''
lst=['hello','world','98','hello']
print(lst)
print(lst[0],lst[-4])
'''创建列表的第二种方式，使用内置函数list()'''
lst2=list(['hello','world',98])
print(lst2)