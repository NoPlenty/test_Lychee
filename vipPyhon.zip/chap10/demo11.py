
def addd(n):
    if n==1:
        return 1
    elif n==2:
        return 1
    else:
        return addd(n-2)+addd(n-1)

#斐波那契数列第六位上的数字
print(addd(6))

print('---------------------------')
#输出这个数列前6位上的数字
for i in range(1,7):
    print(addd(i))