lst = [10, 20, 30, 40, 50, 60, 70, 80]
'''list[start:stop:step]'''
print(lst[1:6:1])

print("原列表：", id(lst))
lst2 = lst[1:6:1]
print('切的片段：', id(lst2))

print('--------------步长为正---------------')
print(lst[1:6]) #默认step为1
print(lst[1:6:])    #省略step
print(lst[1:6:2])
print(lst[:6:2])    #省略start
print(lst[1::2])    #省略stop

print('-------------步长为负----------------')
print('原列表：',lst)
print(lst[::-1])
#start=7,stop省略，step=-1
print(lst[7::-1])
#start=6,stop=0,step=-2
print(lst[6:0:-2])