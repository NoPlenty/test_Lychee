'''元祖的创建方式'''
'''第一种创建方式：使用()'''
t1 = ('hello', 12, 22)
print(t1, type(t1))
print(id(t1))

# 可以省略小括号
t2 = 'nike', 'puma'
print(t2, type(t2))

#如果元祖里只有一个元素，需要加上逗号和小括号，否则会以为是string类型
t3 =('Python',)
print(type(t3))

'''第二种创建方式：使用内置函数tuple()'''
s = tuple(('hello', 12, 22))
print(s, type(s))
print(id(s))

'''空列表空字典空元祖的创建方式'''
lst=[]
lst2=list()

d={}
d2=dict()

t4=()
t5=tuple()

print('空列表',lst,lst2)
print('空字典',d,d2)
print('空元祖',t4,t5)