def fun(*args):  # 函数定义时，个数可变的位置参数
    print(args)
    #print(args[0])


fun(1)
fun(1, 2)
fun(1, 2, 3)


def fun1(**args):  # 函数定义时，个数可变的关键字参数
    print(args)


fun1(a=1)
fun1(a=10, b=20)
fun1(a=11, b=22, c=33)

'''
    def fun2(*arg1,*arg2):
    pass
    以上代码会报错，个数可变的位置参数只能有一个
 
    def fun3(**args,**args2):
        pass
    以上代码会报错，个数可变的关键字参数只能是一个
'''


def fun2(*args1, **args2):
    pass


'''
    def fun3(**args1,*args2):
    pass
    以上代码会报错
    在一个函数定义的过程中，既有个数可变的位置形参也有个数可变的关键字形参，要求将个数可变的位置形参放在个数可变的关键字形参之前
'''
