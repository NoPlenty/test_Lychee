name = '张三'
age = 20

print(type(name), type(age))  # 说明name和age的数据类型不同
# print('我叫' + name + '今年' + age + '岁')  #不能用+连接str类型和int类型
print('我叫' + name + '今年' + str(age) + '岁')  # 用str()函数将int类型转换成了str类型

print('------------str()将其他类型转换成str类型---------------')
a = 10
b = 199.8
c = False
print(type(a), type(b), type(c))
print(str(a), str(b), str(c), type(str(a)), type(str(b)), type(str(c)))

print('------------int()将其他类型转换成int类型---------------')
s1 = '128'
s2 = 98.7
s3 = '76.77'
s4 = True
s5 = 'hello'
print(type(s1), type(s2), type(s3), type(s4), type(s5))
print(int(s1), type(int(s1)))  # 将str转换成int类型，字符串为数字串
print(int(s2), type(int(s2)))  # 将float转换成int类型，剩下整数部分舍去小数部分
# print(int(s3),type(int(s3)))    #将str转换成int类型，报错，因为字符串是小数
print(int(s4), type(int(s4)))
# print(int(s5),type(int(s5)))   #报错，将str转换成int类型时字符串必须为数字串，非数字串不允许转换

print('--------------将其他数据类型转成float类型---------------')
s1 = '128'
s2 = '76'
s3 = True
s4 = 'hello'
s5 = 98
print(type(s1), type(s2), type(s3), type(s4), type(s5))
print(float(s1),type(float(s1)))
print(float(s2),type(s2))
print(float(s3),type(s3))
#print(float(s4),type(s4))    #字符串中的数据如果是非数据串，则不允许转换
print(float(s5),type(s5))