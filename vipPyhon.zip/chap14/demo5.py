#在demo5中导入自定义的模块使用
import calc
print(calc.add(11,22))
print(calc.div(33,3))