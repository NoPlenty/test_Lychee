t=('Python',33,22,11)
'''第一种：使用元祖索引的方法'''
print(t[0])
print(t[1])
print(t[2])

'''第二种：遍历元祖'''
for item in t:
    print(item)