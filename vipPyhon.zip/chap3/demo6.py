# 布尔运算符
print('--------------and------------------')
a, b = 1, 2
print(a == 1 and b == 2)  # True, True and True -->True
print(a == 1 and b < 2)  # False,True and False -->False
print(a != 1 and b != 2)  # False ,False and False -->False

print('-------------or----------------')
a, b = 1, 2
print(a == 1 or b == 2)  # True,True or True -->True
print(a == 1 or b < 2)  # True,True or False -->True
print(a != 1 or b != 2)  # False,False or False -->False

print('---------------not 对bool类型数取反------------------')
f1 = True
f2 = False
print(not f1)

print('-------------------in 与 not in----------------------')
s = 'helloworld'
print('w' in s)
print('k' in s)
print('w' not in s)
print('k' not in s)
