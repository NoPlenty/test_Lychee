s = 'hello,Python'

#居中对齐
print(s.center(20,'*'))

#左对齐
print(s.ljust(20,'*'))
print(s.ljust(10))    #返回原字符
print(s.ljust(20))     #默认填充符为空格

#右对齐
print(s.rjust(20,'*'))
print(s.rjust(10))    #返回原字符
print(s.rjust(20))     #默认填充符为空格

#右对齐，使用0进行填充
print(s.zfill(20))
print(s.zfill(10))    #返回原字符
print('-9876'.zfill(10))