lst=['hello','world',98,'hello','world',234]
#获取索引为2的元素
print(lst[2])
#获取索引为-3的元素
print(lst[-3])

#获取索引为10的元素
#print(lst[10])      #IndexError: list index out of range