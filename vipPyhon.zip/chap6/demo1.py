a = 10  # 变量存储的是一个对象的引用
lst = ['hello', 'world', 98]
print(id(lst))
print(type(lst))
print(lst)
