class Student():  # Student就是类的名称（类名），每个单词的首字母大小，其余小写
    native_pace = '吉林'  # 直接写在类里面的变量，称为类属性

    def __init__(self, name, age):
        self.name = name  # self.name称为实例属性，进行了一个赋值的操作，将局部变量的name的值赋给了实例属性
        self.age = age

    # 实例方法
    def eat(self):
        print('学生在吃饭')

    # 静态方法
    @staticmethod
    def method():  # 不允许写self
        print('我使用了staticmethod进行修饰，所以我是静态方法')

    # 类方法
    @classmethod
    def cm(cls):
        print('我是类方法，因为我使用了classmethod进行修饰')


# 在类之外定义的叫函数，在类里面定义的叫方法
def drink():
    print('学生在喝水')


#创建Student类的对象
stu1=Student('张三',19)
stu1.eat()         #对象名.方法名
print(stu1.name)
print(stu1.age)

Student.eat(stu1)   #34行代码和30行代码功能相同，都是调用Student类中的eat方法
                    #类名.方法名（类的对象）--> 实际上就是方法定义处的self