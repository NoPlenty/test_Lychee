for item in 'Python':  # 第一次取出来的是P,然后赋值给item
    print(item)

# range() 产生一个整数序列，-->也是一个可迭代对象
for i in range(10):
    print(i)

# 如果在循环体中不需要使用到自定义变量，可以将自定义变量写成"_"
for _ in range(5):
    print('人生苦短，我用python')

sum = 0
print('使用for循环，计算1到100之间的偶数和')
for i in range(101):
    if i % 2 == 0:
        sum += i
print('1到100之间的偶数和为:',sum)
