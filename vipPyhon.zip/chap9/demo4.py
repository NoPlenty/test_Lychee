# 字符串的大小写转换
'''注释'''
'''upper() 把字符串中的所有字母都转换成大写字母'''
'''lower（） 把字符串中的所有字母都转换成小写字母'''
'''swapcase() 大写改成小写，小写改成大写'''
'''capitalize 第一个字母转换成大写，其余字母小写'''
'''title（） 把每个单词的第一个字母转换成大写，其他字母改成小写'''

s = 'hello,python'
a = s.upper()  # 转换成大写之后，会产生一个新的字符串变量
print(a, id(a))
print(s, id(s))
b = s.lower()  # 转换成小写之后，会产生一个新的字符串变量
print(b, id(b))
c=s.capitalize()  #产生一个新的字符串变量
print(c,id(c))

s2 = 'hello,Python'
print(s2.swapcase())

print(s2.title())
