#pass语句什么都不做，只是一个占位符，用到需要写语句的地方
answer=input('您是会员吗?y/s')
if answer == 'y':
    pass
else:
    pass
